import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { HeaderNavComponent } from './header-nav/header-nav.component';
import { CustomerListComponent } from './customer-list/customer-list.component';
import { CustomerShowComponent } from './customer-show/customer-show.component';



export const appRoutes: Routes = [

  {
    path: 'customer',
    children: [
      {path: 'list', component: CustomerListComponent},
      {path: 'show/:id', component: CustomerShowComponent}
    ]
  },
 
  
];



@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(appRoutes)
  ],
  exports: [
    RouterModule
  ],
  declarations: []
})
export class AppRoutingModule { }
