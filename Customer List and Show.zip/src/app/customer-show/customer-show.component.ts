import { Component, OnInit } from '@angular/core';
import { CustomerService } from '../shared/service/customer.service';
import { Customer } from '../shared/models/customer';
import {CUSTOMER} from '../shared/models/customer-mock';
import { ActivatedRoute, Router } from '@angular/router';
@Component({
  selector: 'app-customer-show',
  templateUrl: './customer-show.component.html',
  styleUrls: ['./customer-show.component.css']
})
export class CustomerShowComponent implements OnInit {
  customer:Customer;
  constructor(private activatedRoute:ActivatedRoute,private route:Router,private router:Router,private service:CustomerService) { 
  }
  ngOnInit() {
    
  }

  //Fill your code

}
