import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppComponent } from './app.component';
import { RouterModule } from '@angular/router';
import {NgxPaginationModule} from 'ngx-pagination';
import { HeaderNavComponent } from './header-nav/header-nav.component';
import { CustomerListComponent } from './customer-list/customer-list.component';
import { AppRoutingModule } from './app-routing.module';
import { CustomerShowComponent } from './customer-show/customer-show.component';



@NgModule({
  declarations: [
    AppComponent,
    HeaderNavComponent,
    CustomerListComponent,
    CustomerShowComponent    
  ],
  imports: [
    BrowserModule,
    
    RouterModule.forRoot([]),
    NgxPaginationModule,
    AppRoutingModule,
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
