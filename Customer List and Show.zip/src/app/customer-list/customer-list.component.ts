import { Component, OnInit } from '@angular/core';
import { CustomerService } from '../shared/service/customer.service';
import { Customer } from '../shared/models/customer';
import {CUSTOMER} from '../shared/models/customer-mock';
import { Router } from '@angular/router';  

@Component({
  selector: 'app-customer-list',
  templateUrl: './customer-list.component.html',
  styleUrls: ['./customer-list.component.css']
})
export class CustomerListComponent implements OnInit {
  
  constructor() {}
  ngOnInit() {}

//Fill your code  

}
