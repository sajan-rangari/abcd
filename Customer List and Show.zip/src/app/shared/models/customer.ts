export class Customer {
    id : Number;
    name: String;
    username: String;
    password:String;
    email : String;
    contactNumber : String;
    address:String;
    customerId:String;
    customerStatus :Boolean;

    constructor(name:String, username:String, password:String,email:String, contactNumber:String,address:String,customerId:String){
            this.name = name;
            this.username = username;
            this.password = password;
            this.email = email;
            this.address = address;
            this.contactNumber = contactNumber;
            this.customerId = customerId;
    }
}

