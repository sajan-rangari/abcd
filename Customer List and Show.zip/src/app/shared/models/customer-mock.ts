import { Customer } from "./customer";

export const CUSTOMER: Customer[] = [
    {
        id: 1, name: "Aaron", username: "Aaron", password: "Aaron!23", email: "aaronyan@gmail.com", contactNumber: "9952316898", address: "54/12 Car Street, Chennai", customerId: "CUS01", customerStatus: true
    },
    {
        id: 2, name: "Kate", username: "Kate", password: "kate12!@", email: "kate@gmail.com", contactNumber: "9500755118", address: "5th Anna Street, Chennai", customerId: "CUS02", customerStatus:true
    },
    {
        id: 3, name: "Hannah", username: "Hannah", password: "hannah@!123", email: "hannah@gmail.com", contactNumber: "8870025887", address: "8th George Town,Chennai", customerId: "CUS03", customerStatus:false
    },
    {
        id: 4, name: "Riya", username: "riya", password: "riya!@1234", email: "riya@gmail.com", contactNumber: "8852178945", address: "24th Kattor Road, Chennai", customerId: "CUS04", customerStatus:false
    },
    {
        id: 5, name: "Vinoth", username: "vinoth", password: "vinoth", email: "vinoth@gmail.com", contactNumber: "7894561230", address: "54/12 Kani Street, Chennai", customerId: "CUS05", customerStatus:false

    },
    {
        id: 6, name: "Jefre", username: "jefre", password: "Jefre!@1234", email: "jefre@gmail.com", contactNumber: "9659678945", address: "22nd Thambaram, Chennai", customerId: "CUS06", customerStatus: false
    },
    {
        id: 7, name: "Jasiel", username: "Jasiel", password: "jasiel123", email: "jasiel@gmail.com", contactNumber: "9500755118", address: "25th Thambaram, Chennai", customerId: "CUS07", customerStatus:false
    },
    {
        id: 8, name: "Aryan", username: "aryan", password: "aryan232", email: "aryan@gmail.com", contactNumber: "7896541235", address: "8th street Anna Nagar, Chennai", customerId: "CUS08", customerStatus:true
    },
    {
        id: 9, name: "Mallika", username: "Mallika", password: "Mallika789", email: "mallika@gmail.com", contactNumber: "8527419637", address: "6th Park Avenue steet,Chennai", customerId: "CUS09", customerStatus: true
    },
    {
        id: 10, name: "Novoneel", username: "Novoneel", password: "Novoneel145",  email: "novo@gmail.com", contactNumber: "6987456123", address: "8th Anna Salai street, Chennai", customerId: "CUS010", customerStatus: true
    },
    {
        id: 11, name: "Arijit", username: "Arijit", password: "arijith145", email: "arijit@gmail.com", contactNumber: "997651193", address: "8th Park Street, Chennai", customerId: "CUS011", customerStatus:true
    },

]