import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { BrowserModule } from '@angular/platform-browser';
import { QuestionComponent } from './question/question.component';

const appRoutes: Routes = [
   //fill your code
];

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    BrowserModule,
    RouterModule.forRoot(appRoutes,{ enableTracing: true } )
  ],
  exports: [
    RouterModule
  ]
})
export class AppRoutingModule { }
