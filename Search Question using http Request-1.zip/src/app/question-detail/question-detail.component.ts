import { Component, OnInit } from '@angular/core';
import { Question } from '../question/question';
import { QuestionService } from '../question/question.service';
import { Router, ActivatedRoute, ParamMap } from '@angular/router';
import { Observable } from 'rxjs';
import { switchMap } from 'rxjs/operators';

@Component({
  selector: 'app-question-detail',
  templateUrl: './question-detail.component.html',
  styleUrls: ['./question-detail.component.css'],
  providers: [QuestionService],
})
export class QuestionDetailComponent implements OnInit {
  question$: Observable<Question>;
  constructor( private route: ActivatedRoute,
    private router: Router,
    private service: QuestionService) { }

  ngOnInit() {
    this.question$ = this.route.paramMap.pipe(
      switchMap((params: ParamMap) =>
        this.service.getQuestion(params.get('id')))
    );
  }
  gotoQuestions(question: Question) {
    //fill your code here
  }

}
