import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule,FormControl,FormGroup, ReactiveFormsModule }    from '@angular/forms';

import { QuestionComponent }    from '../question/question.component';
import { QuestionDetailComponent }  from '../question-detail/question-detail.component';

import { QuestionRoutingModule } from './question-routing.module';
import {MatFormFieldModule,  MatRippleModule} from '@angular/material';

import {MatInputModule} from '@angular/material';
import {MatButtonModule} from '@angular/material/button';


@NgModule({
 
  imports: [
    CommonModule,
    FormsModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    QuestionRoutingModule
  ],
  declarations: [
     QuestionComponent,
     QuestionDetailComponent
  ]
})
export class QuestionModule { }
