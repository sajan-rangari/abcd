export interface Question {
    id: number;
    name: string;
    answer:string;
  }