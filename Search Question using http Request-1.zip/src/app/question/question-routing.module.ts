import { NgModule }             from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { QuestionComponent }    from './question.component';
import { QuestionDetailComponent }  from '../question-detail/question-detail.component';

const questionRoutes: Routes = [
   //fill your code here
];

@NgModule({
  imports: [
    RouterModule.forChild(questionRoutes)
  ],
  exports: [
    RouterModule
  ]
})
export class QuestionRoutingModule { }

