var express = require('express')
var app = express()
app.set('port', process.env.PORT || 3000)

//fill your code

app.listen(app.get('port'))
